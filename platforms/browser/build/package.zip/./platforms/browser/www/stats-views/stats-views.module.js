'use strict';

// Define the `statsViews` module
angular.module('statsViews', []);