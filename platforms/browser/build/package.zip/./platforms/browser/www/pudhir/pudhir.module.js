'use strict';

// Define the `pudhir` module
angular.module('pudhir', []);