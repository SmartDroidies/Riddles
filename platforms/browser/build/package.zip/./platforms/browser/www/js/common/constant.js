var deviceuuid = "DUMMY_DEVICE";
var recordsToDownload = 10;

/*
var testDevice = '9ff99ad5ec042ed6';
var testDevices = ["9ff99ad5ec042ed6", "c88691ecc215e4fd", "8FDA53DB-41A3-44AA-9BFF-8137EEF0047A", "173356AB4765BF614C5E236309423DCC"];
var interDisplayed = 3;
var analyticsId = 'UA-45773318-1';
var platformios = 'iOS';
var platformAndroid = 'Android';
var platform;
var appversion = '';
var apppackage = '';
var packagePremium = 'com.smart.droidies.tamil.natkati.premium';
var packageFree = 'com.smart.droidies.tamil.natkati';
var premium = false; 

var C_PREF = 'PREF';

var LANG_EN = 'en';
var LANG_TN = 'ta';

var urlNatkal =  "http://www.smartdroidies.com/api/calender.php?service=natkal";

var C_PREFIX_CACHE = "natkati_cache_";
var C_ARTICLETYPE_MAIN = 'MAIN';
*/

