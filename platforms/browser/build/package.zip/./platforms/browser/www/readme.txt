component design - fix items

1. Plugin removed cordova-plugin-appversion
2. Handle Share, Feedback & Rate Me on device
3. Home Navigation on the Pudhir screen


Things to Work in Order

1. Firebase Authentication
2. Load Pudhir from Firebase
3. 