'use strict';

// Define the `home` module
angular.module('home', []);